﻿namespace Ex03
{
    internal class Program
    {
        public static void Main()
        {
            ConsoleUI.Start();
        }
    }
}
