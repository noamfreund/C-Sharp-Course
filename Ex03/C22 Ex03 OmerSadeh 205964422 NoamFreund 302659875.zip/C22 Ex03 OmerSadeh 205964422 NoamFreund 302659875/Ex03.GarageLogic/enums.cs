﻿namespace Ex03
{
    public enum eVehicleType
    {
        ElectricCar, FueledCar, ElectricMotorcycle, FueledMotorcycle, Truck
    }

    public enum eVehicleState
    {
        BeingFixed, Fixed, Paid, None
    }

    public enum eFuelType
    {
        Soler, Octan95, Octan96, Octan98, Electricty
    }
    
    public enum ePaintColor
    {
        Grey, White, Black, Blue
    }

    public enum eLicenceType
    {
        A, AA, B1, BB
    }
}
