﻿namespace Interfaces
{
    public interface IActionListener
    {
        public void RunAction();
    }
}
